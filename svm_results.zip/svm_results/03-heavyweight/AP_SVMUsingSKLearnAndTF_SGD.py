#!/home/users/mtt013/sherpy02/bin/python
#above line selects special python interpreter needed to run espresso
#SBATCH -p iric,suncat
#################
#set a job name
#################
#a file for job output, you can check job progress
#SBATCH --output=myjob.out
#################
# a file for errors from the job
#SBATCH --error=myjob.err
#################
#time you think you need; default is one hour
#in minutes in this case
#SBATCH --time=02:00:00
#################
#number of nodes you are requesting
#SBATCH --nodes=1
#################
#SBATCH --mem-per-cpu=6000
#################
#get emailed about job BEGIN, END, and FAIL
#SBATCH --mail-type=FAIL,END
#################
#who to send email to; please change to your email
#SBATCH --mail-user=apatel6@stanford.edu
#################
#task to run per node; each node has 16 cores
#################
#SBATCH --ntasks-per-node=16
#################

#Option 2: Binary Classification using SKLearn's SVM and TensorFlow
#Author: Stephanie Tietz

from sklearn import svm
from sklearn.model_selection import train_test_split #optional
from sklearn.metrics import classification_report, confusion_matrix,accuracy_score, f1_score
from sklearn.linear_model import SGDClassifier
import numpy as np
import pickle

np.random.seed(seed=1)

#LOAD OUR DATA
traindata = np.load('/scratch/users/apatel6/data/cs230/silicon/Xalphay_train.npy')
X_train = traindata[:,0:-2]
y_train = traindata[:,-1]

devdata = np.load('/scratch/users/apatel6/data/cs230/silicon/Xalphay_dev.npy')
X_dev = devdata[:,0:-2]
y_dev = devdata[:,-1]

classes = np.unique(y_dev)
print 'Number of classes: {}'.format(classes)

#PREPROCESSING
minibatchsize = 2**20
model = SGDClassifier(loss='hinge', penalty='l2', shuffle=False, class_weight={1:200.0, 0:1.0}) #, max_iter = np.ceil(10**6/minibatchsize))
numminibatch = int(np.shape(X_train)[0]/minibatchsize)

print 'shape train: {}'.format(np.shape(X_train))
print minibatchsize

numepoch=100

itercount = 0

for ep in range(numepoch):
	np.random.shuffle(traindata)
	X_train = traindata[:,0:-2]
	y_train = traindata[:,-1]
	for i in range(numminibatch):
		itercount += 1
		minibatch_X = X_train[minibatchsize*i: minibatchsize*(i+1)]
		minibatch_y = y_train[minibatchsize*i: minibatchsize*(i+1)]

		print 'shape mini: {}'.format(np.shape(minibatch_X))

		model.partial_fit(minibatch_X, minibatch_y, classes = classes)
		minibatch_ypred = model.predict(minibatch_X)
		y_pred_dev = model.predict(X_dev)

		print ('Iteration # {:04d}'.format(itercount))
		trainaccuracy = accuracy_score(minibatch_y, minibatch_ypred)
		print("Train Accuracy: {}%".format(trainaccuracy * 100))
		print(confusion_matrix(minibatch_y,minibatch_ypred))  
		print(classification_report(minibatch_y,minibatch_ypred))  

		devaccuracy = accuracy_score(y_dev, y_pred_dev)
		print("Dev Accuracy: {}%".format(devaccuracy * 100))
		print(confusion_matrix(y_dev,y_pred_dev))  
		print(classification_report(y_dev,y_pred_dev))  

		with open('accuracy_train.txt','a') as accfile:
			accfile.write('{}\n'.format(trainaccuracy))
		
		with open('accuracy_dev.txt','a') as accfile:
			accfile.write('{}\n'.format(devaccuracy))

		with open('f1_train.txt','a') as accfile:
			accfile.write('{}\n'.format(f1_score(minibatch_y, minibatch_ypred)))
		
		with open('f1_dev.txt','a') as accfile:
			accfile.write('{}\n'.format(f1_score(y_dev, y_pred_dev)))

		pickle.dump(model,open('SVM_iter_{:04d}.pickle'.format(itercount),'w'))

	minibatch_X = X_train[minibatchsize*(i+1):]
	minibatch_y = y_train[minibatchsize*(i+1):]

	model.partial_fit(minibatch_X, minibatch_y, classes = classes)
	minibatch_ypred = model.predict(minibatch_X)
	y_pred_dev = model.predict(X_dev)

	print ('Iteration # {:04d}'.format(itercount+1))
	trainaccuracy = accuracy_score(minibatch_y, minibatch_ypred)
	print("Train Accuracy: {}%".format(trainaccuracy * 100))
	print(confusion_matrix(minibatch_y,minibatch_ypred))  
	print(classification_report(minibatch_y,minibatch_ypred))  

	devaccuracy = accuracy_score(y_dev, y_pred_dev)
	print("Dev Accuracy: {}%".format(devaccuracy * 100))
	print(confusion_matrix(y_dev,y_pred_dev))  
	print(classification_report(y_dev,y_pred_dev))  

	with open('accuracy_train.txt','a') as accfile:
		accfile.write('{}\n'.format(trainaccuracy))

	with open('accuracy_dev.txt','a') as accfile:
		accfile.write('{}\n'.format(devaccuracy))

	with open('f1_train.txt','a') as accfile:
		accfile.write('{}\n'.format(f1_score(minibatch_y, minibatch_ypred)))

	with open('f1_dev.txt','a') as accfile:
		accfile.write('{}\n'.format(f1_score(y_dev, y_pred_dev)))

	pickle.dump(model,open('SVM_iter_{:04d}.pickle'.format(itercount+1),'w'))

