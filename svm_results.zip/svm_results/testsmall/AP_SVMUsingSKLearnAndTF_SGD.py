#!/home/users/mtt013/sherpy02/bin/python
#above line selects special python interpreter needed to run espresso
#SBATCH -p iric,suncat
#################
#set a job name
#################
#a file for job output, you can check job progress
#SBATCH --output=myjob.out
#################
# a file for errors from the job
#SBATCH --error=myjob.err
#################
#time you think you need; default is one hour
#in minutes in this case
#SBATCH --time=25:00:00
#################
#number of nodes you are requesting
#SBATCH --nodes=1
#################
#SBATCH --mem-per-cpu=6000
#################
#get emailed about job BEGIN, END, and FAIL
#SBATCH --mail-type=FAIL,END
#################
#who to send email to; please change to your email
#SBATCH --mail-user=apatel6@stanford.edu
#################
#task to run per node; each node has 16 cores
#################
#SBATCH --ntasks-per-node=16
#################

#Option 2: Binary Classification using SKLearn's SVM and TensorFlow
#Author: Stephanie Tietz

from sklearn import svm
from sklearn.model_selection import train_test_split #optional
from sklearn.metrics import classification_report, confusion_matrix,accuracy_score, f1_score
from sklearn.linear_model import SGDClassifier
import numpy as np
import pickle

#np.random.seed(seed=1)

#LOAD OUR DATA
traindata = np.load('/scratch/users/apatel6/data/cs230/silicon/Xalphay_smallset.npy')
X_train = traindata[:,0:-2]
y_train = traindata[:,-1]

devdata = np.load('/scratch/users/apatel6/data/cs230/silicon/Xalphay_dev.npy')
X_dev = devdata[:,0:-2]
y_dev = devdata[:,-1]

classes = np.unique(y_dev)
print 'Number of classes: {}'.format(classes)

#PREPROCESSING
model = SGDClassifier(loss='hinge', penalty='none', shuffle=False) #, max_iter = np.ceil(10**6/minibatchsize))

model.partial_fit(X_train, y_train, classes = classes)
train_ypred = model.predict(X_train)
y_pred_dev = model.predict(X_dev)

trainaccuracy = accuracy_score(y_train, train_ypred)
print("Train Accuracy: {}%".format(trainaccuracy * 100))
print(confusion_matrix(y_train, train_ypred))  
print(classification_report(y_train, train_ypred)  )

devaccuracy = accuracy_score(y_dev, y_pred_dev)
print("Dev Accuracy: {}%".format(devaccuracy * 100))
print(confusion_matrix(y_dev,y_pred_dev))  
print(classification_report(y_dev,y_pred_dev))  

